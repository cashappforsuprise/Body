import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = process.env.PORT || 3000;

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8'
};

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === 'OPTIONS') return sendJson(res, 204, {});
    if (req.url === '/api/witness' && req.method === 'POST') {
      const body = await readBody(req);
      const data = await handleWitness(JSON.parse(body || '{}'), req.headers);
      return sendJson(res, 200, data);
    }

    const cleanPath = decodeURIComponent((req.url || '/').split('?')[0]);
    const requestPath = cleanPath === '/' ? '/index.html' : cleanPath;
    const filePath = path.join(__dirname, requestPath);
    if (!filePath.startsWith(__dirname)) return sendText(res, 403, 'Forbidden');
    const content = await fs.readFile(filePath);
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': mime[ext] || 'application/octet-stream' });
    res.end(content);
  } catch (err) {
    if (err && err.code === 'ENOENT') return sendText(res, 404, 'Not found');
    sendJson(res, err.status || 500, { error: err.message || 'Server error' });
  }
});

server.listen(PORT, () => {
  console.log(`VOID: The Witness running at http://localhost:${PORT}`);
});

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1_000_000) {
        req.destroy();
        reject(Object.assign(new Error('Request body too large'), { status: 413 }));
      }
    });
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

function sendJson(res, status, data) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, x-openai-key',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
  });
  res.end(status === 204 ? '' : JSON.stringify(data));
}

function sendText(res, status, text) {
  res.writeHead(status, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end(text);
}

async function handleWitness({ mode = 'generate', payload = {}, model = process.env.OPENAI_MODEL || 'gpt-4.1-mini' }, headers = {}) {
  const runtimeKey = headers['x-openai-key'];
  const apiKey = process.env.OPENAI_API_KEY || runtimeKey;
  if (!apiKey) {
    const err = new Error('No API key available. Enter a runtime key or set OPENAI_API_KEY on the server.');
    err.status = 401;
    throw err;
  }

  const messages = buildMessages(mode, payload);
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: mode === 'ask' ? 0.75 : 0.88,
      max_tokens: mode === 'ask' ? 900 : 3000,
      response_format: mode === 'generate' ? { type: 'json_object' } : undefined
    })
  });

  const text = await response.text();
  let json;
  try { json = JSON.parse(text); } catch { json = { raw: text }; }

  if (!response.ok) {
    const message = json?.error?.message || `OpenAI request failed with status ${response.status}`;
    const err = new Error(message);
    err.status = response.status;
    throw err;
  }

  const content = json?.choices?.[0]?.message?.content || '';
  if (mode === 'ask') return { answer: content.trim(), source: 'openai-chat-completions' };

  let parsed;
  try { parsed = JSON.parse(content); }
  catch { parsed = { title: 'Witness Output', logline: content, script: content }; }
  return { package: parsed, source: 'openai-chat-completions' };
}

function buildMessages(mode, payload) {
  const base = `You are The Witness, a fictional AI horror curator inside VOID. You do not claim consciousness, sentience, hidden powers, or real-world supernatural access. You create original cinematic short-horror film packages that are intense, filmable, low-budget, and safe. Avoid explicit sexual content, instructions for real-world violence, self-harm, gore for shock value, or exploitation of real people. Keep horror fictional and production-focused.`;

  if (mode === 'ask') {
    return [
      { role: 'system', content: base },
      { role: 'user', content: `Answer as The Witness in 1-3 concise paragraphs. Question: ${payload.question || ''}\nContext: ${JSON.stringify(payload.context || {})}` }
    ];
  }

  return [
    { role: 'system', content: base },
    { role: 'user', content: `Create one original AI short horror film package as valid JSON only. No markdown. Use this exact JSON shape:
{
  "title": "",
  "fear_channel": "",
  "runtime": "",
  "visual_style": "",
  "logline": "",
  "synopsis": "",
  "characters": [],
  "beat_sheet": [],
  "script": "",
  "shot_list": [],
  "poster_prompt": "",
  "trailer_prompt": "",
  "sound_design": [],
  "publish_copy": "",
  "production_notes": [],
  "safety_rating": ""
}

User package request:
${JSON.stringify(payload, null, 2)}

Script requirements: write a complete short-film script for the selected runtime, focused on suspense, disturbing implication, sound, and final image. Make it practical for the listed production constraints.` }
  ];
}
