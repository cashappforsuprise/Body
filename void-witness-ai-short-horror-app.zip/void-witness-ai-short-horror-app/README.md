# VOID: The Witness — AI Short Horror Studio

A mobile-ready AI horror app for generating short-film packages from one nightmare seed.

## What it does

- Opens with a **Wake The Witness** API-key screen.
- Keeps your runtime key in browser `sessionStorage` only.
- Also supports a safer public deployment setup with `OPENAI_API_KEY` stored in Netlify environment variables.
- Generates a short-horror package: title, logline, synopsis, characters, beat sheet, full script, shot list, poster prompt, trailer prompt, sound design, production notes, and publish copy.
- Includes a 60-film VOID Originals library with search, categories, likes, My List, and detail modal.
- Has Demo Mode so the app still works without an API key.

## Run locally

You need Node 18 or newer.

```bash
npm start
```

Then open:

```text
http://localhost:3000
```

Enter your OpenAI API key inside the app. Do not paste it into public repos or chat.

## Deploy to Netlify

1. Upload this folder to Netlify or connect it from GitHub.
2. In Netlify, open Site configuration → Environment variables.
3. Add:

```text
OPENAI_API_KEY=your_key_here
OPENAI_MODEL=gpt-4.1-mini
```

4. Redeploy.

When `OPENAI_API_KEY` is set on Netlify, visitors do not need to enter a key. If it is not set, the app lets a user enter their own runtime key.

## Security notes

- The app never hardcodes an API key.
- The browser field stores a key only for the current tab session.
- The server and Netlify function do not save the runtime key.
- For a public app, server-side environment variables are safer than asking users to enter keys.

## Files

- `index.html` — full app UI and local demo generator.
- `server.js` — local Node server and OpenAI proxy route.
- `netlify/functions/witness.mjs` — Netlify serverless OpenAI proxy.
- `netlify.toml` — Netlify publish/function config.
