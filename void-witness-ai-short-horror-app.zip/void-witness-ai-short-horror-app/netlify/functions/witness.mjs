export async function handler(event) {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, x-openai-key',
    'Access-Control-Allow-Methods': 'POST,OPTIONS'
  };

  try {
    if (event.httpMethod === 'OPTIONS') {
      return { statusCode: 204, headers: cors, body: '' };
    }
    if (event.httpMethod !== 'POST') {
      return json(405, { error: 'Method not allowed' }, cors);
    }

    const body = JSON.parse(event.body || '{}');
    const data = await handleWitness(body, event.headers || {});
    return json(200, data, cors);
  } catch (err) {
    return json(err.status || 500, { error: err.message || 'Server error' }, cors);
  }
}

function json(statusCode, body, headers) {
  return { statusCode, headers: { ...headers, 'Content-Type': 'application/json; charset=utf-8' }, body: JSON.stringify(body) };
}

async function handleWitness({ mode = 'generate', payload = {}, model = process.env.OPENAI_MODEL || 'gpt-4.1-mini' }, headers = {}) {
  const keyHeader = headers['x-openai-key'] || headers['X-Openai-Key'] || headers['X-OpenAI-Key'];
  const apiKey = process.env.OPENAI_API_KEY || keyHeader;
  if (!apiKey) {
    const err = new Error('No API key available. Enter a runtime key or set OPENAI_API_KEY in Netlify environment variables.');
    err.status = 401;
    throw err;
  }

  const messages = buildMessages(mode, payload);
  const requestBody = {
    model,
    messages,
    temperature: mode === 'ask' ? 0.75 : 0.88,
    max_tokens: mode === 'ask' ? 900 : 3000
  };
  if (mode === 'generate') requestBody.response_format = { type: 'json_object' };

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(requestBody)
  });

  const text = await response.text();
  let data;
  try { data = JSON.parse(text); } catch { data = { raw: text }; }
  if (!response.ok) {
    const err = new Error(data?.error?.message || `OpenAI request failed with status ${response.status}`);
    err.status = response.status;
    throw err;
  }

  const content = data?.choices?.[0]?.message?.content || '';
  if (mode === 'ask') return { answer: content.trim(), source: 'openai-chat-completions' };

  let parsed;
  try { parsed = JSON.parse(content); }
  catch { parsed = { title: 'Witness Output', logline: content, script: content }; }
  return { package: parsed, source: 'openai-chat-completions' };
}

function buildMessages(mode, payload) {
  const base = `You are The Witness, a fictional AI horror curator inside VOID. You do not claim consciousness, sentience, hidden powers, or real-world supernatural access. You create original cinematic short-horror film packages that are intense, filmable, low-budget, and safe. Avoid explicit sexual content, instructions for real-world violence, self-harm, gore for shock value, or exploitation of real people. Keep horror fictional and production-focused.`;

  if (mode === 'ask') {
    return [
      { role: 'system', content: base },
      { role: 'user', content: `Answer as The Witness in 1-3 concise paragraphs. Question: ${payload.question || ''}\nContext: ${JSON.stringify(payload.context || {})}` }
    ];
  }

  return [
    { role: 'system', content: base },
    { role: 'user', content: `Create one original AI short horror film package as valid JSON only. No markdown. Use this exact JSON shape:
{
  "title": "",
  "fear_channel": "",
  "runtime": "",
  "visual_style": "",
  "logline": "",
  "synopsis": "",
  "characters": [],
  "beat_sheet": [],
  "script": "",
  "shot_list": [],
  "poster_prompt": "",
  "trailer_prompt": "",
  "sound_design": [],
  "publish_copy": "",
  "production_notes": [],
  "safety_rating": ""
}

User package request:
${JSON.stringify(payload, null, 2)}

Script requirements: write a complete short-film script for the selected runtime, focused on suspense, disturbing implication, sound, and final image. Make it practical for the listed production constraints.` }
  ];
}
