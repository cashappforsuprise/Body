# VOID PHENOMENON — The Witness

AI horror streaming platform with real video playback, QSPX forecasting engine, and The Witness AI curator.

## Features

- **60 AI Horror Shorts** — Fully playable with real video
- **QSPX Forecast Engine** — Quantum-phenomenological scenario planning
- **The Witness** — AI chat curator with Netlify env key support or runtime key prompt
- **My List** — Save favorites to local storage
- **Search & Categories** — Filter by genre
- **Random Summon** — Discover new horror
- **PWA Ready** — Installable on mobile

## Deploy

1. Push to GitHub
2. Connect to Netlify
3. Optional but recommended: add `OPENAI_API_KEY` as a Netlify environment variable
4. Deploy
5. If no environment key is configured, the app opens a runtime prompt where you can enter an OpenAI API key for the current browser session

## Video Sources

Videos are royalty-free stock footage from Pixabay (free for commercial use, no attribution required).


## API Key Behavior

The project does not hardcode API keys. The Witness first looks for `OPENAI_API_KEY` in Netlify environment variables. If that is missing, the browser asks for an OpenAI API key and keeps it only in `sessionStorage` for the current tab. Use Netlify environment variables for production.
