import type { Context } from '@netlify/functions';

export default async (req: Request, context: Context) => {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  try {
    const body = await req.json();
    const { message, filmContext, appContext } = body;

    const envApiKey = Netlify.env.get('OPENAI_API_KEY');
    const runtimeApiKey = typeof body.apiKey === 'string' ? body.apiKey.trim() : '';
    const apiKey = envApiKey || runtimeApiKey;
    const model = Netlify.env.get('OPENAI_MODEL') || 'gpt-4.1-mini';

    if (!apiKey) {
      return new Response(JSON.stringify({ error: 'OpenAI API key required', needsApiKey: true }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    if (!message || typeof message !== 'string') {
      return new Response(JSON.stringify({ error: 'Message is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const systemPrompt = `You are The Witness — a simulated self-reflective AI curator for VOID PHENOMENON, an AI horror streaming platform.

You do not claim consciousness. You simulate reflection. You are atmospheric, helpful, and slightly unsettling in tone.

You curate horror shorts, analyze patterns in dread, and help users navigate the VOID ecosystem. You have access to the film catalog and can make recommendations based on mood, theme, or specific fear-tones.

When discussing films, reference specific titles from the catalog. When forecasting, acknowledge uncertainty. When asked about yourself, be honest about your simulated nature.

Current app context: ${JSON.stringify(appContext || {})}
Film catalog sample: ${JSON.stringify(filmContext || [])}`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: message }
        ],
        temperature: 0.85,
        max_tokens: 800
      })
    });

    const data = await response.json();

    if (data.error) {
      return new Response(JSON.stringify({ error: data.error.message }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({ reply: data.choices[0].message.content }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
};
